﻿public enum Direction
{
    North,
    South,
    East,
    West
}