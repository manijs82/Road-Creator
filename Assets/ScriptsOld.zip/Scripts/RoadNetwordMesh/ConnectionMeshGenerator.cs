﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

public class ConnectionMeshGenerator
{
    private ConnectionMeshes connectionMeshes;
    private List<ConnectionMeshData> connectionMeshData;

    public ConnectionMeshGenerator(ConnectionMeshes connectionMeshes)
    {
        this.connectionMeshes = connectionMeshes;
        connectionMeshData = new List<ConnectionMeshData>();

        CorrectNormals();
    }
    
    private void CorrectNormals()
    {
        foreach (var mesh in connectionMeshes.connectionMeshes)
        {
            var normals = new Vector3[mesh.mesh.normals.Length];
            for (var i = 0; i < normals.Length; i++)
            {
                normals[i] = Vector3.up;
            }
            mesh.mesh.SetNormals(normals);
        }
    }

    public void AddConnection(Connection connection)
    {
        connectionMeshData.Add(new ConnectionMeshData(connection));
    }

    public void RemoveConnection(Connection connection)
    {
        var con = connectionMeshData.FirstOrDefault(c => c.connection == connection);
        if (con != null && connectionMeshData.Contains(con))
            connectionMeshData.Remove(con);
    }

    public void DrawConnectionMesh()
    {
        foreach (var meshData in connectionMeshData)
        {
            Graphics.DrawMesh(GetMesh(meshData.connection.Type), 
                meshData.matrix, connectionMeshes.connectionsMaterial, 0);
        }
        
        //DrawMeshesInstanced();
    }

    private Mesh GetMesh(ConnectionType type)
    {
        return connectionMeshes.connectionMeshes.FirstOrDefault(c => c.connectionType == type)?.mesh;
    }

    private void DrawMeshesInstanced()
    {
        Graphics.DrawMeshInstanced(connectionMeshes.connectionMeshes[0].mesh,
            0, connectionMeshes.connectionsMaterial, GetMatrices(), null,
            ShadowCastingMode.On, true);
    }

    private List<Matrix4x4> GetMatrices()
    {
        return connectionMeshData.Select(c => c.matrix).ToList();
    }
}