﻿using UnityEngine;

public class RoadVisualizer : MonoBehaviour
{
    [SerializeField] private RoadNetworkCreator creator;
    [SerializeField] private ConnectionMeshes connectionMeshes;
    
    private RoadMeshGenerator roadMeshGenerator;
    private ConnectionMeshGenerator connectionMeshGenerator;
    
    private void Start()
    {
        roadMeshGenerator = new CubicMeshRoadGenerator(connectionMeshes.connectionsMaterial);
        connectionMeshGenerator = new ConnectionMeshGenerator(connectionMeshes);

        creator.roadNetwork.OnAddRoad += OnAddRoad;
        creator.roadNetwork.OnRemoveRoad += OnRemoveRoad;
        creator.roadNetwork.OnAddConnection += OnAddConnection;
        creator.roadNetwork.OnRemoveConnection += OnRemoveConnection;
        RoadNetworkEditor.OnEditRoad += OnEditRoad;
    }

    private void Update()
    {
        roadMeshGenerator.DrawRoadMesh();
        connectionMeshGenerator.DrawConnectionMesh();
    }

    private void OnAddRoad(Road road)
    {
        roadMeshGenerator.AddRoad(road);
        connectionMeshGenerator.AddConnection(road.Start);
        connectionMeshGenerator.AddConnection(road.End);
    }
    
    private void OnRemoveRoad(Road road)
    {
        roadMeshGenerator.RemoveRoad(road);
        connectionMeshGenerator.RemoveConnection(road.Start);
        connectionMeshGenerator.RemoveConnection(road.End);
    }
    
    private void OnAddConnection(Connection connection)
    {
        connectionMeshGenerator.AddConnection(connection);
    }
    
    private void OnRemoveConnection(Connection connection)
    {
        connectionMeshGenerator.RemoveConnection(connection);
    }
    
    private void OnEditRoad(Road road)
    {
        roadMeshGenerator.EditRoad(road);
    }
}