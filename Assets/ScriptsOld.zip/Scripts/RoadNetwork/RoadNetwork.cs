﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

public class RoadNetwork
{
    public const int GridSize = 3;
    
    public event Action<Road> OnAddRoad;
    public event Action<Road> OnRemoveRoad;
    public event Action<Connection> OnAddConnection;
    public event Action<Connection> OnRemoveConnection;
    
    private readonly List<Road> roads;
    private readonly List<Connection> connections;

    public List<Road> Roads => roads;
    public List<Connection> Connections => connections;

    public RoadNetwork()
    {
        roads = new List<Road>();
        connections = new List<Connection>();
    }

    public void AddRoad(Road road)
    {
        roads.Add(road);
        OnAddRoad?.Invoke(road);
    }

    public void RemoveRoad(Road road)
    {
        if (!Roads.Contains(road)) return;
        Roads.Remove(road);
        RemoveConnection(road);
        OnRemoveRoad?.Invoke(road);
    }

    public void AddConnection(Connection connection)
    {
        connections.Add(connection);
        connection.road1.AddIntersection(connection);
        connection.road2.AddIntersection(connection);
        
        OnAddConnection?.Invoke(connection);
    }
    
    public void RemoveConnection(Connection connection)
    {
        connections.Remove(connection);
        connection.road1.RemoveIntersection(connection);
        connection.road2.RemoveIntersection(connection);
        
        OnRemoveConnection?.Invoke(connection);
    }
    
    public void RemoveConnection(Road road)
    {
        var cons = connections.Where(c => c.HasRoad(road)).ToArray();

        foreach (var connection in cons)
        {
            RemoveConnection(connection);
        }
    }

    public List<Road> GetConnectedRoads(Road road)
    {
        var output = new List<Road>();
        var cons = connections.Where(c => c.HasRoad(road)).ToArray();

        foreach (var connection in cons)
        {
            if(connection.road1 == road) output.Add(connection.road2);
            if(connection.road2 == road) output.Add(connection.road1);
        }

        return output;
    }

    public bool HasConnection(Connection connection) => 
        connections.Contains(connection);

    public Connection[] GetIntersections()
    {
        return connections.ToArray();
    }

    public void DrawAllGizmos()
    {
        foreach (var road in roads)
            DrawRoad(road);
        foreach (var connection in connections)
            DrawIntersection(connection);
    }

    private void DrawRoad(Road road)
    {
        Gizmos.color = road.selectedInEditor ? Color.blue : Color.red;
        var r = road.selectedInEditor ? 1.5f : 1f;
        Gizmos.DrawSphere(road.roadLine.StartXZ, r);
        Gizmos.DrawSphere(road.roadLine.EndXZ, r);
        Handles.color = road.selectedInEditor ? Color.cyan : Color.green;
        Handles.DrawAAPolyLine(5 * r, road.roadLine.StartXZ, road.roadLine.EndXZ);
    }

    private void DrawIntersection(Connection connection)
    {
        if(connection.Type != ConnectionType.Intersection) return;
        Gizmos.color = connection.selectedInEditor ? Color.yellow : Color.Lerp(Color.yellow, Color.cyan, .5f);
        var r = connection.selectedInEditor ? 1.5f : 1f;
        Gizmos.DrawCube(connection.PointXZ, Vector3.one * r);
    }
}