﻿using System.Collections.Generic;
using UnityEngine;

public class Road
{
    public Line roadLine;
    public bool selectedInEditor;

    private readonly List<Connection> intersections;
    private readonly RoadType roadType;
    
    public Connection Start { get; }
    public Connection End { get; }
    public bool IsHorizontal => roadType == RoadType.Horizontal;

    public List<Connection> Intersections => intersections;

    public Road(Line roadLine)
    {
        this.roadLine = roadLine;
        intersections = new List<Connection>();

        roadType = roadLine.IsHorizontalLine ? RoadType.Horizontal : RoadType.Vertical;

        Start = new Connection(roadLine.start, this, null, ConnectionType.End,
            roadLine.IsHorizontalLine ? Direction.East : Direction.North);
        End = new Connection(roadLine.end, this, null, ConnectionType.End,
            roadLine.IsHorizontalLine ? Direction.West : Direction.South);

        Start.OnChangePoint += ChangeStartPoint;
        End.OnChangePoint += ChangeEndPoint;
    }

    public void AddIntersection(Connection intersection)
    {
        intersections.Add(intersection);
    }
    
    public void RemoveIntersection(Connection intersection)
    {
        intersections.Remove(intersection);
    }

    private void ChangeStartPoint(Vector2Int newStartPoint)
    {
        roadLine.start = newStartPoint;
    }

    private void ChangeEndPoint(Vector2Int newEndPoint)
    {
        roadLine.end = newEndPoint;
    }

    public bool HasPoint(Vector2Int point) =>
        roadLine.OnLine(point);
    
    public bool HasPointInside(Vector2Int point) =>
        roadLine.InsideLine(point);

    public bool HasConnection(Vector2Int point) =>
        End.Point == point || Start.Point == point;

    public Connection GetConnection(Vector2Int point)
    {
        if (End.Point == point) return End;
        if (Start.Point == point) return Start;
        return null;
    }
}

public enum RoadType
{
    Horizontal,
    Vertical
}