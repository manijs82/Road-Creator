﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class RoadNetworkEditor
{
    public static event Action<Road> OnEditRoad;
    
    protected readonly RoadNetwork network;
    protected List<Road> Roads => network.Roads;

    protected RoadNetworkEditor(RoadNetwork network)
    {
        this.network = network;
    }

    public virtual void EditNetwork(Line line) { }
    public virtual void EditNetwork(Vector2Int point) { }

    protected void RoadEdited(Road road) => 
        OnEditRoad?.Invoke(road);

    protected Connection GetRoadConnection(Vector2Int point, out Road road)
    {
        foreach (var r in Roads)
        {
            var connection = r.GetConnection(point);
            if (connection == null) continue;
            
            road = r;
            return connection;
        }

        road = null;
        return null;
    }

    protected IEnumerable<Road> GetRoadsWithConnection(Vector2Int point) =>
        Roads.Where(road => road.HasConnection(point));

    protected void CalculateIntersections(Road road)
    {
        network.RemoveConnection(road);
        foreach (var r in Roads)
        {
            if(CheckForIntersections(road, r))
                continue;
            // if(CheckForTurnAround(road, r))
            //     continue;
            CheckForThreeWay(road, r);
        }
    }

    private bool CheckForIntersections(Road road1, Road road2)
    {
        if (road2.IsHorizontal == road1.IsHorizontal) return false;

        if (LineExtensions.LineLineIntersection(road1.roadLine, road2.roadLine, out var point))
        {
            var pointInt = new Vector2Int(Mathf.RoundToInt(point.x), Mathf.RoundToInt(point.y));
            var connection = new Connection(pointInt, road1, road2, ConnectionType.Intersection);

            network.AddConnection(connection);
            RoadEdited(road1);
            RoadEdited(road2);
            return true;
        }

        return false;
    }

    private bool CheckForTurnAround(Road road1, Road road2)
    {
        if (road2.IsHorizontal == road1.IsHorizontal) return false;

        if (road1.Start.Point == road2.Start.Point)
        {
            road1.Start.ChangeType(ConnectionType.Turn);
            road2.Start.ChangeType(ConnectionType.Turn);
            return true;
        }
        if (road1.Start.Point == road2.End.Point)
        {
            road1.Start.ChangeType(ConnectionType.Turn);
            road2.End.ChangeType(ConnectionType.Turn);
            return true;
        }

        if (road1.End.Point == road2.Start.Point)
        {
            road1.End.ChangeType(ConnectionType.Turn);
            road2.Start.ChangeType(ConnectionType.Turn);
            return true;
        }
        if (road1.End.Point == road2.End.Point)
        {
            road1.End.ChangeType(ConnectionType.Turn);
            road2.End.ChangeType(ConnectionType.Turn);
            return true;
        }
        if(road1.End.Point != road2.Start.Point && road1.End.Point != road2.End.Point)
            road1.End.ChangeType(ConnectionType.End);
        if(road1.Start.Point != road2.End.Point && road1.Start.Point != road2.Start.Point)
            road1.Start.ChangeType(ConnectionType.End);
        return false;
    }

    private void CheckForThreeWay(Road road1, Road road2)
    {
        if (road2.IsHorizontal == road1.IsHorizontal) return;

        if (road1.HasPointInside(road2.Start.Point))
        {
            road2.Start.ChangeType(ConnectionType.ThreeWay);
            var connection = new Connection(road2.Start.Point, road1, road2, ConnectionType.ThreeWay);
            network.AddConnection(connection);
        }
        if (road1.HasPointInside(road2.End.Point))
        {
            road2.End.ChangeType(ConnectionType.ThreeWay);
            var connection = new Connection(road2.End.Point, road1, road2, ConnectionType.ThreeWay);
            network.AddConnection(connection);
        }
        if (road2.HasPointInside(road1.Start.Point))
        {
            road1.Start.ChangeType(ConnectionType.ThreeWay);
            var connection = new Connection(road1.Start.Point, road1, road2, ConnectionType.ThreeWay);
            network.AddConnection(connection);
        }
        if (road2.HasPointInside(road1.End.Point))
        {
            road1.End.ChangeType(ConnectionType.ThreeWay);
            var connection = new Connection(road1.End.Point, road1, road2, ConnectionType.ThreeWay);
            network.AddConnection(connection);
        }
        OnEditRoad?.Invoke(road2);
        OnEditRoad?.Invoke(road1);
    }
}