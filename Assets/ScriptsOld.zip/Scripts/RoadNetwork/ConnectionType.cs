﻿public enum ConnectionType
{
    End,
    Turn,
    ThreeWay,
    Intersection,
    Road
}