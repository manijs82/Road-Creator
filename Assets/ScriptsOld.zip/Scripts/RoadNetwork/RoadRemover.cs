﻿using System.Linq;
using UnityEngine;

public class RoadRemover : RoadNetworkEditor
{
    public RoadRemover(RoadNetwork network) : base(network)
    {
    }

    public override void EditNetwork(Vector2Int point)
    {
        RemoveRoad(point);
    }

    private void RemoveRoad(Vector2Int point)
    {
        var road = GetRoad(point);
        if (road == null) return;

        var connectedRoads = network.GetConnectedRoads(road);
        network.RemoveRoad(road);

        foreach (var connectedRoad in connectedRoads)
        {
            RoadEdited(connectedRoad);
        }
    }

    private Road GetRoad(Vector2Int point) => 
        Roads.FirstOrDefault(r => r.HasPoint(point));
}