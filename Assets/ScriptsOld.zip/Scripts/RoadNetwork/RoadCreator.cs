﻿using System.Linq;
using UnityEngine;

public class RoadCreator : RoadNetworkEditor
{
    public RoadCreator(RoadNetwork network) : base(network)
    {
    }

    public override void EditNetwork(Line line)
    {
        AddRoad(line);
    }

    private void AddRoad(Line line)
    {
        line.Straighten();
        line.Sort();

        if (!CanPlaceRoad(line)) return;

        Road road = new Road(line);
        var combinedRoad = TryCombiningRoads(road);
        
        CalculateIntersections(combinedRoad);
        network.AddRoad(combinedRoad);
    }

    private bool CanPlaceRoad(Line line)
    {
        return Roads.All(road => !LineExtensions.Overlap(road.roadLine, line)) &&
               line.Magnitude > RoadNetwork.GridSize && !line.IsDiagonalLine;
    }

    private Road TryCombiningRoads(Road road)
    {
        Road finalRoad;
        
        var roadsWithStart = GetRoadsWithConnection(road.roadLine.end);
        foreach (var r in roadsWithStart)
        {
            if (!LineExtensions.Collinear(r.roadLine, road.roadLine)) continue;
            r.Start.ChangePoint(road.roadLine.start);
            finalRoad = r;
            network.RemoveRoad(r);
            
            return TryCombiningRoads(finalRoad);
        }

        var roadsWithEnd = GetRoadsWithConnection(road.roadLine.start);
        foreach (var r in roadsWithEnd)
        {
            if (!LineExtensions.Collinear(r.roadLine, road.roadLine)) continue;
            r.End.ChangePoint(road.roadLine.end);
            finalRoad = r;
            network.RemoveRoad(r);

            return TryCombiningRoads(finalRoad);
        }

        return road;
    }
}