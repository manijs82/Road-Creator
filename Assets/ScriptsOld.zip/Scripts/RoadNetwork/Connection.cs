﻿using System;
using UnityEngine;

public class Connection
{
    public event Action<Vector2Int> OnChangePoint;
    public event Action<ConnectionType> OnChangeType;

    public bool selectedInEditor;
    public Road road1;
    public Road road2;
    
    private Vector2Int point;

    public Vector2Int Point => point;
    public Vector3 PointXZ => new (point.x, 0, point.y);
    public ConnectionType Type { get; private set; }
    public Direction Direction { get; }
    
    public Connection()
    {
        point = Vector2Int.zero;
        Type = ConnectionType.End;
        Direction = Direction.North;
    }

    public Connection(Vector2Int point, Road road1, Road road2 = null, ConnectionType type = ConnectionType.End, Direction direction = Direction.North)
    {
        this.point = point;
        Type = type;
        Direction = direction;
        this.road1 = road1;
        this.road2 = road2;
    }

    public void ChangeType(ConnectionType type)
    {
        if(type == Type) return;
        
        Type = type;
        OnChangeType?.Invoke(type);
    }

    public void ChangePoint(Vector2Int point)
    {
        this.point = point;
        OnChangePoint?.Invoke(point);
    }
    
    public void ChangePointWithoutEvent(Vector2Int point)
    {
        this.point = point;
    }

    public bool HasRoad(Road road)
    {
        return road1 == road || road2 == road;
    }
}